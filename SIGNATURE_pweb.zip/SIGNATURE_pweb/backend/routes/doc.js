import express from "express";
import {
    getDocuments,
    getDocumentById,
    saveDocument,
    updateDocument,
    deleteDocument
} from "../controllers/doc.js";

const router = express.Router();

router.get('/Document', getDocuments);
router.get('/Document/:id', getDocumentById);
router.post('/Document', saveDocument);
router.patch('/Document/:id', updateDocument);
router.delete('/Document/:id', deleteDocument);

export default router;