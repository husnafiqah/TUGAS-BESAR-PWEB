import { Sequelize } from "sequelize";
import db from "../config/Database.js";

const { DataTypes } = Sequelize;

const Document = db.define('document',{
    document_id:{
        type: DataTypes.STRING,
        autoIncrement: true,
        primaryKey: true
    },
    nama:{
        type: DataTypes.STRING,
        allowNull: true
    },
    filenama:{
        type: DataTypes.STRING,
        allowNull: true
    },
    description:{
        type: DataTypes.STRING,
        allowNull: true
    },
    url: DataTypes.STRING
},{
    freezeTableName:true
});

export default Document;
