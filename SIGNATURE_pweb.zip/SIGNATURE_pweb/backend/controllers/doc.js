import Document from "../models/DocumentModel.js";
import path from "path";
import fs from "fs";

export const getDocuments = async(req, res)=>{
    try {
        const response = await Document.findAll();
        res.json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const getDocumentById = async(req, res)=>{
    try {
        const response = await Document.findOne({
            where:{
                document_id : req.params.id
            }
        });
        res.json(response);
    } catch (error) {
        console.log(error.message);
    }
}

export const saveDocument = (req, res)=>{
    if(req.files === null) return res.status(400).json({msg: "No File Uploaded"});
    const name = req.body.title;
    const description = req.body.title;
    const file = req.files.file;
    const fileSize = file.data.length;
    const ext = path.extname(file.name);
    const fileName = file.md5 + ext;
    const url = `${req.protocol}://${req.get("host")}/file/${fileName}`;
    const allowedType = ['.pdf'];

    if(!allowedType.includes(ext.toLowerCase())) return res.status(422).json({msg: "Invalid file"});
    if(fileSize > 5000000) return res.status(422).json({msg: "file must be less than 5 MB"});

    file.mv(`./public/file/${fileName}`, async(err)=>{
        if(err) return res.status(500).json({msg: err.message});
        try {
            await Document.create({nama: name, filename: fileName, url: url, description : description});
            res.status(201).json({msg: "Document Created Successfuly"});
        } catch (error) {
            console.log(error.message);
        }
    })

}

export const updateDocument = async(req, res)=>{
    const Document = await Document.findOne({
        where:{
            id : req.params.id
        }
    });
    if(!Document) return res.status(404).json({msg: "No Data Found"});
    
    let fileName = "";
    if(req.files === null){
        fileName = Document.file;
    }else{
        const file = req.files.file;
        const fileSize = file.data.length;
        const ext = path.extname(file.name);
        fileName = file.md5 + ext;
        const allowedType = ['.pdf'];

        if(!allowedType.includes(ext.toLowerCase())) return res.status(422).json({msg: "Invalid file"});
        if(fileSize > 5000000) return res.status(422).json({msg: "File must be less than 5 MB"});

        const filepath = `./public/file/${Document.file}`;
        fs.unlinkSync(filepath);

        file.mv(`./public/file/${fileName}`, (err)=>{
            if(err) return res.status(500).json({msg: err.message});
        });
    }
    const name = req.body.title;
    const url = `${req.protocol}://${req.get("host")}/file/${fileName}`;
    
    try {
        await Document.update({name: name, filename: fileName, url: url},{
            where:{
                id: req.params.id
            }
        });
        res.status(200).json({msg: "Document Updated Successfuly"});
    } catch (error) {
        console.log(error.message);
    }
}

export const deleteDocument = async(req, res)=>{
    const Document = await Document.findOne({
        where:{
            id : req.params.id
        }
    });
    if(!Document) return res.status(404).json({msg: "No Data Found"});

    try {
        const filepath = `./public/file/${Document.image}`;
        fs.unlinkSync(filepath);
        await Document.destroy({
            where:{
                id : req.params.id
            }
        });
        res.status(200).json({msg: "Document Deleted Successfuly"});
    } catch (error) {
        console.log(error.message);
    }
}