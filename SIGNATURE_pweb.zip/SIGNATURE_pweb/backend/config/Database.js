import {Sequelize} from "sequelize";

const db = new Sequelize('db_pweb','root','',{
    host: "localhost",
    dialect: "mysql"
});

export default db;